/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Game_;

import java.io.IOException;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Amr
 */
public class PlayGame_FormTest {
    
    public PlayGame_FormTest() {
    }
    

    @Test
    public void testPlayGame() throws ClassNotFoundException, IOException {
        
        PlayGame_Form play1 = new PlayGame_Form();
        AddGame_FormTest add = new AddGame_FormTest ();
        add.testAddGame();
        String actual =play1.Category="Science";
        String expected = "Sorry >> There is No Game In this Category !!";
        assertTrue(actual.equals(expected));
        
        
       
       
        
    }
    
}
