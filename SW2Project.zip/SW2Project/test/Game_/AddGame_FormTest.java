/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Game_;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static org.hamcrest.CoreMatchers.notNullValue;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author Roqaia
 */
public class AddGame_FormTest {
    
    public AddGame_FormTest() {
    }

    @Test
    public void testAddGame() throws ClassNotFoundException, IOException {
        
        AddGame_Form Game1 = new AddGame_Form();
        Game1.g.GameName="Smart Scientist ";
        Game1.g.Category="Science";
        
        Game1.g.Questions.add (0,"H2O is stands for :");
        Game1.g.Questions.add (1,"water");
        Game1.g.Questions.add (2,"NaCl is stands for :");
        Game1.g.Questions.add (3,"salt");
        
        
        Game1.g.Answers.add (0,"water");
        Game1.g.Answers.add (1,"sun");
        Game1.g.Answers.add (2,"salt");
        Game1.g.Answers.add (3,"soil");
        Game1.g.Answers.add (4,"sun");
        Game1.g.Answers.add (5,"water");
        Game1.g.Answers.add (6,"salt");
        Game1.g.Answers.add (7,"soil");
        
        Game1.g.Type = "MCQ";
        
        Controller.Add_Game(Game1.g);
        
        
        
        
    }
    
    private BufferedReader in = null;
    

    @Before
    public void setup()
        throws IOException
    {
        in = new BufferedReader(
            new InputStreamReader(getClass().getResourceAsStream("GDB.txt")));
    }

    @After
    public void teardown()
        throws IOException
    {
        if (in != null)
        {
            in.close();
        }

        in = null;
    }

    @Test
    public void testGDBFile()
        throws IOException
    {
        String line = in.readLine();

        assertThat(line, notNullValue());
    }
}
