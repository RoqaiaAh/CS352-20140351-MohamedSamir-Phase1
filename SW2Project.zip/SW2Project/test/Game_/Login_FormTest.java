/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Game_;

import java.io.FileNotFoundException;
import java.io.IOException;
import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Hagar
 */
public class Login_FormTest {

    public Login_FormTest() {
    }

    @Test
    public void testLogin() throws IOException, FileNotFoundException, ClassNotFoundException {

        Login_Form log = new Login_Form();
        log.UserName = "Ahmed";
        log.Password = "1234";

        Controller ctr = new Controller();

        Login_Form.job = Controller.Login(log.UserName, log.Password);
        Assert.assertEquals(log.job,"Student");
     
    }
}
