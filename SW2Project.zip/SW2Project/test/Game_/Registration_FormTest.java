/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Game_;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import static org.hamcrest.CoreMatchers.notNullValue;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author Doaa
 * @class test of Registration_Form
 */
public class Registration_FormTest {

    public Registration_FormTest() {
    }

    @Test
    public void testRegister() throws IOException {

        // pass and suppose to pass 
        Registration_Form teacher_1 = new Registration_Form();
        teacher_1.FName = "Mohamed";
        teacher_1.LName = "Samir";
        teacher_1.Gender = "male";
        teacher_1.Age = 30;
        teacher_1.UserName = "Mohamed Samir";
        teacher_1.Password = "123456";
        teacher_1.Job = "Teacher";

        Assert.assertEquals(teacher_1.Get_Job(), "Teacher");
        
        
        Registration_Form teacher_3 = new Registration_Form();
        teacher_3.FName="khaled";
        teacher_3.LName="ali";
        teacher_3.Gender="male";
        teacher_3.Age=30;
        teacher_3.UserName="khaled ali";
        teacher_3.Password="123456";
        teacher_3.Job="teacher";
        
        Assert.assertEquals( teacher_3.Get_Job(), "teacher");
        
         // success and suppose to success
        Registration_Form teacher_4 = new Registration_Form();
        teacher_4.FName="Mohamed";
        teacher_4.LName="Amr";
        teacher_4.Gender="male";
        teacher_4.Age=20;
        teacher_4.UserName="Mohamed Amr";
        teacher_4.Password="123456";
        teacher_4.Job="TeaCher";
        
        Assert.assertEquals( teacher_4.Get_Job(), "TeaCher");
        
        
        // success and suppose to success 
        Registration_Form student_1 = new Registration_Form();
        student_1.FName="Esraa";
        student_1.LName="Mohamed";
        student_1.Gender="female";
        student_1.Age=30;
        student_1.UserName="Esraa Mohamed";
        student_1.Password="123456";
        student_1.Job="Student";
        
        Assert.assertEquals( student_1.Get_Job(), "Student");
        
        
         // success and suppose to success
        Registration_Form student_2 = new Registration_Form();
        student_2.FName="Doaa";
        student_2.LName="Ghaleb";
        student_2.Gender="female";
        student_2.Age=20;
        student_2.UserName="Doaa Ghaleb";
        student_2.Password="123456";
        student_2.Job="StuDent";
        
        Assert.assertEquals( student_2.Get_Job(), "StuDent");
        
        
        // success and suppose to success
         Registration_Form student_3 = new Registration_Form();
        student_3.FName="Roqaia";
        student_3.LName="Ahmed";
        student_3.Gender="female";
        student_3.Age=20;
        student_3.UserName="Roqaia Ahmed";
        student_3.Password="123456";
        student_3.Job="student";
        
        Assert.assertEquals( student_3.Get_Job(), "student");
          
    
        RegistrationFile_FormTest r= new RegistrationFile_FormTest();
             
        }
    @Test
    public void testRegisterTwice() throws IOException {
    
    // pass but suppose to fail because there is already someone have the same name
        Registration_Form teacher_2 = new Registration_Form();
        teacher_2.FName="Mohamed";
        teacher_2.LName="Samir";
        teacher_2.Gender="male";
        teacher_2.Age=30;
        teacher_2.UserName="Mohamed Samir";
        teacher_2.Password="123456";
        teacher_2.Job="Teacher";
        
        Assert.assertEquals( teacher_2.Get_Job(), "Teacher");
        RegistrationFile_FormTest r= new RegistrationFile_FormTest();

    }
         
    private BufferedReader in = null;
    

    @Before
    public void setup()
        throws IOException
    {
        in = new BufferedReader(
            new InputStreamReader(getClass().getResourceAsStream("UDB.txt")));
    }

    @After
    public void teardown()
        throws IOException
    {
        if (in != null)
        {
            in.close();
        }

        in = null;
    }

    @Test
    public void testUDBFile()
        throws IOException
    {
        String line = in.readLine();

        assertThat(line, notNullValue());
    }
}
