package Game_;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;

public class PlayGame_Form {

	String Category;
	
	public PlayGame_Form() throws FileNotFoundException, ClassNotFoundException, IOException {
		
		Scanner s=new Scanner(System.in);
		System.out.println("____________________________________________________________________________________");
		System.out.println("Enter The Category : ");
		Category=s.nextLine();
		Controller.Show_Games(Category);
		
	}

	public static void play_game(Vector<Game> games_Found) {
	
		if(games_Found.isEmpty())
		{
			System.out.println("Sorry >> There is No Game In this Category !!");
		}
		else{
		boolean found=false;
		Scanner s=new Scanner(System.in);
		
		System.out.println("Enter the Name Of Game You Want to play : ");
		String p= s.nextLine();
		
		for (int i=0;i<games_Found.size()&&!found;i++)
		{
			if(games_Found.get(i).GameName.equals(p))
			{
				found =true;
				if(games_Found.get(i).Type.equals("MCQ")||games_Found.get(i).Type.equals("mcq"))
				{
					MCQ s1=new MCQ(games_Found.get(i));
				}
				else
				{
					T_OR_F v=new T_OR_F(games_Found.get(i));
				}
			}
		}
		
	}
	}


}
