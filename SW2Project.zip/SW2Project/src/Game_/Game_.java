package Game_;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.Scanner;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JPanel;




public class Game_ extends JPanel  {
	 
	      
	public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, IOException {
	
		Scanner s=new Scanner(System.in);
		boolean Continue=true;
		
		while(true){
		System.out.println("____________________________________________________________________________________");
		System.out.println("     < Sing Up >                                                     < Login >");	
		System.out.println("____________________________________________________________________________________");
		System.out.println("Enter Your  Choice ( Sign Up / Login ) : ");
		String a = s.nextLine();
		
		
		if(a.equals("login") ||a.equals("Login"))
		{
		
			Login_Form l=new Login_Form();
			l.Login();
//			System.out.println("dsadasf sadf sa");
			
		if(Login_Form.Get_Job().equals("Teacher"))
		{
			while(true){
			System.out.println("____________________________________________________________________________________");
			System.out.println("     < Play Game >                                                    < Add Game >");	
			System.out.println("____________________________________________________________________________________");
			System.out.println("Enter Your  Choice ( Play Game / Add Game ) : ");	
			String n=s.nextLine();
			if(n.equals("Play Game")||n.equals("play game"))
			{
				PlayGame_Form f=new PlayGame_Form();
			}
			else 
			{
				AddGame_Form j=new AddGame_Form();
				
			}
			System.out.print("          <<< Do you Want To exit( Y / N ) >>>");
			Character t=s.next().charAt(0);
			s.nextLine();
			if(t.equals('y')||t.equals('Y'))
			{
				break;
			}
			}
			break;
		}
		
		
		else if(Login_Form.Get_Job().equals("Student"))
		{
			do{
//				System.out.println("dssdas fads");
			PlayGame_Form j=new PlayGame_Form();
			System.out.print("          <<< Do you Want To exit( Y / N ) >>>");
		
			Character t=s.next().charAt(0);
			if(t.equals('y')||t.equals('Y'))
			{
				Continue=false;
			}
			}
			while (Continue==true);
			break;
		}
		
		else if(Login_Form.Get_Job().equals("NULL"))
		{
			
		}
		}
		
///////////////////////////////////////////////Sugn Up//////////////////////////////////////////////////////		
		else
		{
		Registration_Form r=new Registration_Form();
		r.Registration();
//System.out.println(r.Get_Job());
	if(r.Get_Job().equals(("Teacher")))
	{
		while(true){
		System.out.println("____________________________________________________________________________________");
		System.out.println("     < Play Game >                                                    < Add Game >");	
		System.out.println("____________________________________________________________________________________");
		System.out.println("Enter Your  Choice ( Play Game / Add Game ) : ");	
		String n=s.nextLine();
		
		if(n.equals("Play Game")||n.equals("play game")||n.equals("Play game"))
		{
			PlayGame_Form f=new PlayGame_Form();
		}
		else 
		{
			AddGame_Form j=new AddGame_Form();
			
		}
		System.out.print("          <<< Do you Want To exit( Y / N ) >>>");
		Character t=s.next().charAt(0);
		s.nextLine();
		if(t.equals('y')||t.equals('Y'))
		{
			break;
		}
		}
		break;
	}
	else if(r.Get_Job().equals(("Student")))
	{
		while(true){
			
		PlayGame_Form p=new PlayGame_Form();
		System.out.print("          <<< Do you Want To exit( Y / N ) >>>");
		Character t=s.next().charAt(0);
//		s.nextLine();
		if(t.equals('y')||t.equals('Y'))
		{
			break;
		}
	}
		}
	break;
		}
		
		
//		AddGame_Form s=new AddGame_Form();
//		Controller.Add_Game(s);

//		AddGame_Form d=new AddGame_Form();
//		Controller.Add_Game(d);
//		PlayGame_Form f=new PlayGame_Form();

		}
	}
}
