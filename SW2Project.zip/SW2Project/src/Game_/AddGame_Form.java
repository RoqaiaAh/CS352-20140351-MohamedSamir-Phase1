package Game_;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;
import Game_.Controller;
import Game_.Game;

public class AddGame_Form implements java.io.Serializable{

	
	Game g=new Game();
	public AddGame_Form() throws FileNotFoundException, ClassNotFoundException, IOException 
	{
		Scanner s=new Scanner (System.in);
		
		
		
		System.out.println("Enter Your Name : ");
		g.TeacherName=s.nextLine();
		System.out.println("Enter Your Game Name : ");
		g.GameName=s.nextLine();
		System.out.println("Enter Your Game Category : ");
		g.Category=s.nextLine();
		System.out.println("Enter The Type Of the Game( MCQ / TOF) ");
		g.Type =s.nextLine();
		System.out.println("Enter Your Number of Questions ");
		Integer a=s.nextInt();
		s.nextLine();
		System.out.println("_______________________________________________________________________________________________________");		
		for (int i=0;i<a;i++)
		{
			int l=i*2;

			System.out.println("Enter The "+(i+1)+" Question");
			
			String k=s.nextLine();
			g.Questions.add(l,k);
			System.out.println("Enter The Correct Answer");
			
			String b = s.nextLine();
			
			g.Questions.add(l+1, b);;
			if(g.Type.equals("MCQ")||g.Type.equals("mcq"))
			{
			for(int j=0;j<4;j++)
			{
				System.out.println("Enter Available Answers ");	
				String o=s.nextLine();
				g.Answers.add(o);
			}
			}
			else
			{
				g.Answers.add("T");
				g.Answers.add("F");
			}
				
			System.out.println("_______________________________________________________________________________________________________");
		}
		
	Controller.Add_Game(g);	
	}

}
