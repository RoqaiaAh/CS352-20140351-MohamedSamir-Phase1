package Game_;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Registration_Form implements java.io.Serializable{
String UserName;
String FName;
String LName;
String Gender;
String Password;
Integer Age;
String Job;



	public  void Registration() throws FileNotFoundException, ClassNotFoundException, IOException 
	{
		Scanner s=new Scanner(System.in);
		String d;
		System.out.println("Signg Up As Teacher Or Student");
		d=s.nextLine();
		if(d.equals("Teacher")||d.equals("teacher")){
		System.out.println("Enter Your Frist Name : ");
		FName=s.nextLine();
		System.out.println("Enter Your Last Name : ");
		LName=s.nextLine();
		System.out.println("Enter Your User Name : ");
		UserName=s.nextLine();
		System.out.println("Enter Your Gender : ");
		Gender=s.nextLine();
		System.out.println("Enter Your Password : ");
		Password=s.nextLine();
		System.out.println("Enter Your Age : ");
		Age=s.nextInt();
		Job="Teacher";
		Controller.Registration(UserName,FName,LName,Gender,Password, Age,Job);
		System.out.println("                  < Sign Up Successfully Done >             ");

		}
		
		else
		{
			System.out.println("Enter Your Frist Name : ");
			FName=s.nextLine();
			System.out.println("Enter Your Last Name : ");
			LName=s.nextLine();
			System.out.println("Enter Your User Name : ");
			UserName=s.nextLine();
			System.out.println("Enter Your Gender : ");
			Gender=s.nextLine();
			System.out.println("Enter Your Password : ");
			Password=s.nextLine();
			System.out.println("Enter Your Age : ");
			Age=s.nextInt();
			Job="Student";
			Controller.Registration(UserName,FName,LName,Gender,Password, Age,Job);
			System.out.println("                  < Sign Up Successfully Done >             ");
		}
		
	}



	public String Get_Job() 
	{
		return Job;
	}
	

}
