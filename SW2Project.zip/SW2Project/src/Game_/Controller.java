package Game_;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;
//import java.io.Serializable;

import org.omg.PortableInterceptor.USER_EXCEPTION;



public class Controller {
 
	static String job;
	public static final boolean True = false;
////////////////////////////////////////////////////REGISTRATION/////////////////////////////////////////////////////////////////	
	public static String Registration(String UserName,String FName,String LName,String Gender,String Password,Integer Age,String Job) throws FileNotFoundException, IOException, ClassNotFoundException 
	
	{
		Registration_Form U=new Registration_Form();
		U.UserName=UserName;
		U.FName=FName;
		U.LName=LName;
		U.Gender=Gender;
		U.Password=Password;
		U.Age=Age;
		U.Job=Job;
	    Vector<Registration_Form> Users = new Vector<Registration_Form>();

	    InputStream is = new FileInputStream("UDB.txt");
	    if (is.read() != -1) {
	    	
		    final ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream("UDB.txt")));

		    Users = (Vector<Registration_Form>) in.readObject();
		   
	    Users.add(U);
	    
	    //System.out.println(" " + Users);
	    final ObjectOutputStream out = new ObjectOutputStream(
	        new BufferedOutputStream(new FileOutputStream("UDB.txt")));

	    try {
	      out.writeObject(Users);
	    } finally {
	      out.close();
	    }
	    
	    } else {
	    	
	    	Users.add(U);
	    	final ObjectOutputStream out = new ObjectOutputStream(
	    	        new BufferedOutputStream(new FileOutputStream("UDB.txt")));

	    	    try {
	    	      out.writeObject(Users);
	    	    } finally {
	    	      out.close();
	    	    }
	    }
	    
	    return U.Job;


	}
///////////////////////////////////////////////////LOGIN///////////////////////////////////////////////////////////	
	public static String Login(String UserName, String Password) throws FileNotFoundException, IOException, ClassNotFoundException 
	{
		
//		Login_Form l =new Login_Form();
//		l.UserName=UserName;
//		l.Password=Password;
		boolean found =false;
	    final ObjectInputStream in = new ObjectInputStream(
		        new BufferedInputStream(new FileInputStream("UDB.txt")));
	    	
	    final Vector<Registration_Form> Users = (Vector<Registration_Form>) in.readObject();
		    Integer size=Users.size();
		    for(int i=0;i<size;i++)
		    {
		    	//System.out.print(Users.get(i).UserName+"=="+U+"  "+Users.get(i).Password+"=="+P);
		    	if(Users.get(i).UserName.equals(UserName)&&Users.get(i).Password.equals(Password)&&!found)
		    	{	
		    		found=true;
		    		
		    		return Users.get(i).Job;
		    	}

		    	
		    }
			if(!found)
			{
				
				Login_Form s=new Login_Form();
				return "NULL";
				
				
			}
			return null;
			
			
			
			
		    
		    //System.out.println("Products from file: " + productsFromFile.get(0).FName);
	}
	
/////////////////////////////////////////////////ADD GAME/////////////////////////////////////////////////////////////////////	
	public static boolean Add_Game(Game G) throws FileNotFoundException, IOException, ClassNotFoundException
	{
		Vector<Game> Games = new Vector<Game>();

	    InputStream is = new FileInputStream("GDB.txt");
	    if (is.read() != -1) {
	    	
		    final ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream("GDB.txt")));

		    Games = (Vector<Game>) in.readObject();
		   
	    Games.add(G);
	    
	    

//	    System.out.println("Original products : " + Games);

	    final ObjectOutputStream out = new ObjectOutputStream(
	        new BufferedOutputStream(new FileOutputStream("GDB.txt")));

	    try {
	      out.writeObject(Games);
	    } finally {
	      out.close();
	    }
	    
	    } else {
	    	
	    	Games.add(G);
	    	final ObjectOutputStream out = new ObjectOutputStream(
	    	        new BufferedOutputStream(new FileOutputStream("GDB.txt")));

	    	    try {
	    	      out.writeObject(Games);
	    	    } finally {
	    	      out.close();
	    	    }
	    }

	    System.out.println("            << Game Add Successful >> ");
		return false;

	}
/////////////////////////////////////////////////PLAY GAME//////////////////////////////////////////////////////////////////	
	public static void Show_Games(String s ) throws FileNotFoundException, IOException, ClassNotFoundException 
	{
		Vector<Game> Games_Found = new Vector<Game>() ;
		
				boolean found = false ;
		final ObjectInputStream in = new ObjectInputStream(
		        new BufferedInputStream(new FileInputStream("GDB.txt")));
	    	
	    final Vector<Game> Games = (Vector<Game>) in.readObject();
		    Integer size=Games.size();
		    for(int i=0;i<size;i++)
		    {
		    	found=false;
		    	//System.out.print(Users.get(i).UserName+"=="+U+"  "+Users.get(i).Password+"=="+P);
		    	if(Games.get(i).Category.equals(s))
		    	{
		    		System.out.println(Games.get(i).GameName);
		    		
		    		Games_Found.add(Games.get(i));
		    		
		    		found=true;
		    	}
		    	
		    }
		    PlayGame_Form.play_game(Games_Found);
		   // Play_game(Games_Found);
		    //System.out.println("Products from file: " + productsFromFile.get(0).FName);
	}
	
//	public static void  Play_game(Vector<Game> games_Found)
//	{
//		boolean found=false;
//		Scanner s=new Scanner(System.in);
//		
//		System.out.println("Enter the Name Of Game You Want to play : ");
//		String p= s.nextLine();
//		
//		for (int i=0;i<games_Found.size()&&!found;i++)
//		{
//			if(games_Found.get(i).GameName.equals(p))
//			{
//				found =true;
//				if(games_Found.get(i).Type.equals("MCQ")||games_Found.get(i).Type.equals("mcq"))
//				{
//					MCQ s1=new MCQ(games_Found.get(i));
//				}
//				else
//				{
//					T_OR_F v=new T_OR_F(games_Found.get(i));
//				}
//			}
//		}
	}
	
	
	
	
	
	