package Game_;

import java.io.Serializable;
import java.util.Scanner;
import java.util.Vector;
import java.io.BufferedInputStream;

public class Game implements java.io.Serializable {

	String GameName;
	String Category;
	String TeacherName;
	String Type;
	Vector<String> Questions = new Vector<String>();
	Vector<String> Answers = new Vector<String>();
	
}
