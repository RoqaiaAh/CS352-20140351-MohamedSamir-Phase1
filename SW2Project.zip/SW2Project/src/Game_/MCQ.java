package Game_;

import java.util.Scanner;
import java.util.Vector;

public class MCQ extends Game {
	
//	Vector<String>Questions=new Vector<String>();
//	Vector<String> answers=new Vector<String>();
	int Score=0;
	
	public MCQ(Game m) 
	{
		Scanner s=new Scanner(System.in);
System.out.println("____________________________________________________________________________");		
System.out.println("This Game IS MCQ Game >> There is ("+((m.Questions.size())/2)+") Question \n ");
System.out.println("____________________________________________________________________________");

		int size =m.Questions.size();
		for (int i=0; i < size-1 ; i+=2)
		{
			System.out.println("Q"+(i+1)+"/ "+m.Questions.get(i));
			
			for(int j=(i)*2 ;j<((i)*2)+4;j++)
			{

				System.out.println (m.Answers.get(j));
			}
			

			System.out.println("Enter Your Answer : ");
			String a = s.nextLine();
			checker(m,i,a);
		}
		Show_Score(m);
		
	}
	
	public void checker(Game m, int i, String a) {
		//System.out.println(Questions.get(i+1)+equals(a));
		if(m.Questions.get(i+1).equals(a))
		{
			System.out.println("< True >");
			Score++;
		}
		else 
		{
			System.out.println("< False >");
		}
		
	}

	public void Show_Score(Game m)
	{
		System.out.println("____________________________________________________________________________________");
		System.out.println("Your Score : "+Score +" / "+m.Questions.size()/2);
		System.out.println("____________________________________________________________________________________");
	}

}

