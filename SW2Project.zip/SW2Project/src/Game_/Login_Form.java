package Game_;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import Game_.Controller;

public class Login_Form {

	String UserName;
	String Password;
	static String job;
	public  void Login() throws FileNotFoundException, ClassNotFoundException, IOException 
	{
	Scanner s=new Scanner(System.in);
	
		System.out.println("USER NAME : ");
		UserName=s.nextLine();
		System.out.println("PASSWORD : ");
		Password=s.nextLine();
		job=Controller.Login(UserName, Password);
		if(job.equals("Teacher")||job.equals("Student"))
		{
			System.out.println("                   < Login Successfully Done >              ");
		}
		else
		{
			System.out.println("                   < Login Faild >");
		}
		
	}

	public static  String Get_Job()
	{
		return job;
	}
}
