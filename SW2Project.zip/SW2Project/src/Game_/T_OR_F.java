package Game_;

import java.util.Scanner;
import java.util.Vector;

public class T_OR_F extends Game {

	int Score=0;
	
	public T_OR_F(Game m) 
	{
		Scanner s=new Scanner(System.in);
		String a;
		int size =m.Questions.size();
		System.out.println("____________________________________________________________________________");		
		System.out.println("This Game IS True Or False  Game >> There is ("+((m.Questions.size())/2)+") Question \n ");
		System.out.println("____________________________________________________________________________");

		for (int i=0; i < size ; i+=2)
		{
			System.out.println("Q"+(i+1)+"/ "+m.Questions.get(i));
			for(int j=0 ;j<2;j++)
			{
				System.out.println (m.Answers.get(j));
			}
			System.out.println("Enter Your Answer : ");
			a=s.nextLine();
			checker(m,i,a);
		}
		Show_Score(m);
		
	}
	
	public void checker(Game m, int i, String a) {
		
		if(m.Questions.get(i+1).equals(a))
		{
			System.out.println("< True >");
			Score++;
		}
		else 
		{
			System.out.println("< False >");
		}
		
	}

	
	
	public void Show_Score(Game m)
	{
		System.out.println("Your Score : "+Score +" / "+m.Questions.size()/2);
		
	}

}
